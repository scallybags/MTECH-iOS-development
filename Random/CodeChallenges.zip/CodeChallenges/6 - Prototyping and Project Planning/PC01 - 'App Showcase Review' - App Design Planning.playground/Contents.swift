//  🏔️ MTECH Code Challenge PC01: "App Showcase Review"
//  Concept: Generate app ideas by reviewing past students' work

//  Instructions:
    //  Review the most recently available App Showcase from a previous cohort's students:
    //  🔗https://github.com/MTechMobileDevelopment/Mobile-Development-Lesson-Plans/tree/master/App%20Showcases
    //  With a partner or as a class, look through the apps submitted to the app store by previous cohorts. Discuss them.
        //  Which ones have an appealing pitch? What draws you to one app over another? What similar ideas could you pitch for your app? etc.
    //  You can take notes on your answers to those questions below.

// MARK: Student response
/*
 
 */
