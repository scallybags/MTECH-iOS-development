//  🏔️ MTECH Code Challenge SD18-20: "Mock Interviews"
//  Concept: Practice accessing a set of data in an array that is not the entire array; practice using index subscripting

//  Instructions:
    //  For today's code challenge, you will complete a mock job interview with an instructor.
        //  You will be provided a code challenge to begin the interview. Your work will be analyzed as part of the interview process to see if you got the job.
        //  You will receive a second challenge after you complete the first.
        //  You will need to create separate Xcode projects for these challenges.

    //  When finished, record any feedback you received about how to better perform in an interview here.
/*
 Feedback:
 
 
 */
