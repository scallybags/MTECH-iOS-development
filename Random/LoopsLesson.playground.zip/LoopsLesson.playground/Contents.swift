import UIKit

// MARK - For Loops


let names = ["Alice", "Bob", "Charlie", "Diana", "Eve"]


let vehicles = ["unicycle" : 1, "bicycle" : 2, "tricycle" : 3, "quad bike" : 4]


// Mark - While Loops

var numberOfLives = 3



// Mark - Control Transfer Statements






// Helper Methods

func playMove() {
    print("Playing a move!")
}

@MainActor
func updateLivesCount() {
    numberOfLives -= 1
}
